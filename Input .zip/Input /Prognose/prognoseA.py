import csv
import collections
from operator import add

timeDict = {}

for time in range(6, 22):
	for minutes in range(0, 4):
		if time == 21 and minutes == 3:
			break
		if minutes > 0:
			timeDict[tuple([time * 100 + minutes * 15, time * 100 + (minutes + 1) * 15 - 1])] = [0] * 18
		else:
			timeDict[tuple([time * 100 + minutes * 15, time * 100 + (minutes + 1) * 15 - 1])] = [0] * 18

timeDict = collections.OrderedDict(sorted(timeDict.items()))
with open('pass_progn.csv', 'r') as csvfile:
	spamreader = csv.reader(csvfile, delimiter=';', quotechar='|')
	i = 0
	for row in spamreader:
		try:
			if 'total' not in row[0]:
				entering = [int(x) for x in [row[1], row[3], row[5]]]
				leaving = [int(x) for x in [row[2], row[4], row[6]]]
				for key in timeDict:
					if (key[0] < 700) or  (key[0] >= 900 and key[0] < 1600) or (key[0] >= 1800 and key[0] < 2200) :
						timeDict[key][i] = round(float(entering[0] - entering[1] - entering[2]) / 48, 2)
						timeDict[key][i + 9] = round(float(leaving[0] - leaving[1] - leaving[2]) / 48, 2)
						# if timeDict[key][i] != 0:
						# 	timeDict[key][i] = round(float(900.0 / timeDict[key][i]), 2)
					elif key[0] >= 700 and key[0] < 900:
						timeDict[key][i] = round(float(entering[1] / 8), 2)
						timeDict[key][i + 9] = round(float(leaving[1] / 8), 2) 
					else:
						timeDict[key][i] = round(float(entering[2] / 8), 2)
						timeDict[key][i + 9] = round(float(leaving[2] / 8), 2) 
				i += 1	
				if i > 8:
					break			
		except ValueError: 
			pass

for key in timeDict:
	proc = [0.0] * 9
	totpass = 0
	entering = timeDict[key][:9]
	leaving = timeDict[key][9:]
	for i in range(9):
		if totpass != 0:
			proc[i] = round((float(leaving[i]) / float(totpass)) * 100, 1)
		totpass += entering[i]
		totpass -= leaving[i]	
	for i in range(9,18):
		timeDict[key][i] = proc[i - 9]	

with open("prognA.csv", "w") as resf:

	for key in timeDict:

		if len(str(key[0])) == 3:
			t1 = str(key[0])[0] + ":" + str(key[0])[1:]
		else:
			t1 = str(key[0])[0:2] + ":" + str(key[0])[2:]

		if len(str(key[1])) == 3:
			t2 = str(key[1])[0] + ":" + str(key[1])[1:]
		else:
			t2 = str(key[1])[0:2] + ":" + str(key[1])[2:]

		resf.write(t1 + "-" + t2 + ";")
		timeDict[key] = [str(x) for x in timeDict[key]]
		resf.write(";".join(timeDict[key]) + "\n")