import csv

csvin = open('prognB_mod.csv', 'r')
csvout = open('prognB_mod2.csv', 'w') 

csvr = csv.reader(csvin, delimiter=';', quotechar='|')
csvw = csv.writer(csvout, delimiter=';', quotechar='|')
for row in csvr:
	for idx in range(1, 10):
		row[idx] = round(900.0 / float(row[idx]), 2)
	csvw.writerow(row)
