import csv

csvin = open('prognA.csv', 'r')
csvout = open('prognA_mod.csv', 'w') 

csvr = csv.reader(csvin, delimiter=';', quotechar='|')
csvw = csv.writer(csvout, delimiter=';', quotechar='|')
for row in csvr:
	for idx in range(1, 10):
		if float(row[idx]) == 0:
			row[idx] = 0.02
		else: 
			row[idx] = row[idx]
	csvw.writerow(row)
