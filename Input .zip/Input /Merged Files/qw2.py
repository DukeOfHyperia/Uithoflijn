import csv

csvin1 = open('prognA_mod2.csv', 'r')
csvin2 = open('12Amod.csv', 'r')
csvout = open('Result_A.csv', 'w') 

csvr1 = csv.reader(csvin1, delimiter=';', quotechar='|')
csvr2 = csv.reader(csvin2, delimiter=';', quotechar='|')
csvw = csv.writer(csvout, delimiter=';', quotechar='|')
for row in zip(csvr1, csvr2):
	for idx in range(1, 18):
		if idx < 3:
			row[0][idx] = row[0][idx]
		else:
			row[0][idx] = round((float(row[0][idx]) + float(row[1][idx - 2 ])) / 2, 2)
	csvw.writerow(row[0])

csvin1.close()
csvin2.close()
csvout.close()
