import csv
import collections
from operator import add


counter = 0 
timeDict = {}

for time in range(6, 22):
	for minutes in range(0, 4):
		if time == 21 and minutes == 3:
			break
		if minutes > 0:
			timeDict[tuple([time * 100 + minutes * 15, time * 100 + (minutes + 1) * 15 - 1])] = [0] * 18
		else:
			timeDict[tuple([time * 100 + minutes * 15, time * 100 + (minutes + 1) * 15 - 1])] = [0] * 18

timeDict = collections.OrderedDict(sorted(timeDict.items()))
with open('12b.csv', 'r') as csvfile:
	spamreader = csv.reader(csvfile, delimiter=';', quotechar='|')
	for row in spamreader:
		if counter > 1:
			
			entering = [int(x) for x in row[3:12]]
			leaving = [int(x) for x in row[12:21]]
			
			timeString = int(row[2].replace(":", ""))
			for key in timeDict:
				if timeString >= key[0] and timeString <= key[1]:
					for i in range(9):
						timeDict[key][i] += entering[i]
						timeDict[key][i + 9] += leaving[i]
		counter += 1
print(timeDict)		
for key in timeDict:
	proc = [0.0] * 9
	totpass = 0
	entering = timeDict[key][:9]
	leaving = timeDict[key][9:]
	for i in range(9):
		if totpass != 0:
			proc[i] = round((float(leaving[i]) / float(totpass)) * 100, 1)
		totpass += entering[i]
		totpass -= leaving[i]	
	for i in range(9,18):
		timeDict[key][i] = proc[i - 9]	
		

with open("12Bmod.csv", "w") as resf:

	for key in timeDict:

		if len(str(key[0])) == 3:
			t1 = str(key[0])[0] + ":" + str(key[0])[1:]
		else:
			t1 = str(key[0])[0:2] + ":" + str(key[0])[2:]

		if len(str(key[1])) == 3:
			t2 = str(key[1])[0] + ":" + str(key[1])[1:]
		else:
			t2 = str(key[1])[0:2] + ":" + str(key[1])[2:]

		resf.write(t1 + "-" + t2 + ";")
		print(timeDict[key])
		timeDict[key] = [str(x) for x in timeDict[key]]
		resf.write(";".join(timeDict[key]) + "\n")